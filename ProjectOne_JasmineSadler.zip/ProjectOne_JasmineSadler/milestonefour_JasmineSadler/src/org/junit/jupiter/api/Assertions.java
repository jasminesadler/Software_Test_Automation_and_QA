package org.junit.jupiter.api;

public class Assertions {

	public static void assertEquals(String description, String description2) {
		// TODO Auto-generated method stub
		
	}

}
