public class Task {
//memeber varibales 
    public String taskId;
    public String name;
    public String description;

//parameterized constructor 
    public Task(String taskId, String name, String description) {
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }
//setters and getters
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
    	this.name = name;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
    	this.description = description;
    }
	public void updateName(String name2) {
		
	}
	public void updateDescription(String description2) {
		
	}
}