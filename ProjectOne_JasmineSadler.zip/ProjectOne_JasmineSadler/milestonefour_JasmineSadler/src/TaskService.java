import java.util.ArrayList;


public class TaskService {
public static ArrayList<Task> tasks;


public static boolean addTask(Task task) {
	boolean alreadyTask = false;

	for (Task taskList : tasks) {
		if (taskList.getTaskId().equals(task.getTaskId())) {
			alreadyTask = true;
		}
	}
	if (!alreadyTask) {
		tasks.add(task);

	}
	return alreadyTask;
}

	public static boolean deleteTask(Task task) {
		for (Task taskList : tasks) {
			if (taskList.getTaskId().equals(task.getTaskId())) {
				tasks.remove(task);
				return true;
			}
		}
		return false;
	}

	public static boolean updateTask(Task task) {
		for (Task taskList : tasks) {
			if (taskList.getTaskId().equals(task.getTaskId())) {
				taskList.updateName(task.getName());
				taskList.updateDescription(task.getDescription());
				return true;
			}
		}
		return false;
		}
	}