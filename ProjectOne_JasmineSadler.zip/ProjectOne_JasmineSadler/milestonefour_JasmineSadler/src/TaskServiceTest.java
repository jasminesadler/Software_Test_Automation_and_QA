import org.junit.Test;

public class TaskServiceTest {


	@Test
	public void testAdd() {
		Task test1 = new Task("2000101213", "Clean", "Do the Dishes");
		assertEquals(false, TaskServiceTest.addTask(test1));
	}

	private static boolean addTask(Task test1) {
		return false;
	}

	public void assertEquals(boolean b, boolean addTask) {
		
	}

	@Test
	public void noDoubleIDTest() {
		Task test1 = new Task("200101213", "Clean", "Do the dishes");
		TaskServiceTest.addTask(test1);
		Task test2 = new Task("2000101213", "Cook", "Prepare lunch for tomorrow");
		assertEquals(false, TaskServiceTest.addTask(test2));
}

	@Test
	public void deleteTest() {
		Task test1 = new Task("2000101213", "Clean", "Do the dishes");
		TaskServiceTest.addTask(test1);
		assertEquals(true, TaskServiceTest.deleteTask(test1));
	}

	private static boolean deleteTask(Task test1) {
		return false;
	}

	@Test
	public void updateTest() {
		Task test1 = new Task("2000101213", "Clean", "Do the dishes");
		TaskServiceTest.addTask(test1);
		Task test2 = new Task("2000101213", "Cook", "Prepare lunch for tomorrow");
		TaskServiceTest.updateTask(test2);
	}

	private static void updateTask(Task test2) {
		
	}

}