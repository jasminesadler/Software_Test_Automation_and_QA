import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.Test;

public class TaskTest {
        String taskId = "2000101213";
        String name = "Task Name";
        String description = "Task Description";

        Task task = new Task(taskId, name, description);

        @Test
        public void getTaskId() {
             assertEquals("2000101213", task.getTaskId());
         }

         @Test
         public void getName() {
             assertEquals("Task Name", task.getName());
         }

         @Test
         public void getDescription() {
             assertEquals("Task Description", task.getDescription());
         }

         @Test
         public void testToString() {
             assertEquals("Task [taskId=2000101213, name= Task Name, description= Task Description]", task.toString());
         }

   }
